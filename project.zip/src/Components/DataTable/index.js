/*import TableHeader from "./Header";
import Pagination from "./Pagination";
import Search from "./Search";

export { TableHeader, Pagination, Search };*/

import React from 'react';

const Datatable = ({ data }) =>{
    const columns = data[0] && Object.keys(data[0])
    return (
        <div className="card">
        <table cellPadding={0} cellSpacing={0}>
            <thead>
                <tr>{data[0] && columns.map((heading) => <th>{heading}</th>)}</tr>
            </thead>
            <tbody>
                {data.map((row) => (
                    <tr>
                        {columns.map((column) => (
                            <td>{row[column]}</td>
                        ))}                        
                    </tr>
                ))}
            </tbody>
            <tfoot>

            </tfoot>
        </table>
        </div>
    )
}

export default Datatable;